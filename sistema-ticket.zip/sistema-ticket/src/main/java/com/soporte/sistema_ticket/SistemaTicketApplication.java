package com.soporte.sistema_ticket;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SistemaTicketApplication {

	public static void main(String[] args) {
		SpringApplication.run(SistemaTicketApplication.class, args);
	}

}
